const sub = require("./index");

console.log(sub(40, 20));